<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExtraCharge extends Model
{
    //
}
