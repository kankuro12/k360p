<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PackagingCharge extends Model
{
    //
}
