<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WeightClass extends Model
{
    //
}
