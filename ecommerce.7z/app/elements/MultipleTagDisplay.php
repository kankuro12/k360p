<?php

namespace App\elements;

use Illuminate\Database\Eloquent\Model;

class MultipleTagDisplay extends Model
{
    //
}
