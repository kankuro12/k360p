<?php

namespace App\elements;

use Illuminate\Database\Eloquent\Model;

class MultipleTagDisplayItem extends Model
{
    //
}
