<?php

namespace App\elements;

use Illuminate\Database\Eloquent\Model;

class Section extends Model
{
    //
}
