<?php

namespace App\elements;

use Illuminate\Database\Eloquent\Model;

class TagDisplay extends Model
{
    //
}
