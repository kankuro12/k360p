<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{
    //
}
