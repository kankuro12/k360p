<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Coupon_setting extends Model
{
    //
}
