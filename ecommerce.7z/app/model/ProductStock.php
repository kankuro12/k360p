<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class ProductStock extends Model
{
    //
}
