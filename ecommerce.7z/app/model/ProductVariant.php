<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class ProductVariant extends Model
{
    //
}
