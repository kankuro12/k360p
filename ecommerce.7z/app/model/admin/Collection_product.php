<?php

namespace App\model\admin;

use Illuminate\Database\Eloquent\Model;

class Collection_product extends Model
{
    //
}
