<?php

namespace App\model\admin;

use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
    //
}
