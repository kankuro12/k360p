<?php

namespace App\model\admin;

use Illuminate\Database\Eloquent\Model;

class Onsell extends Model
{
    //
    protected $primaryKey = 'sell_id';
}
