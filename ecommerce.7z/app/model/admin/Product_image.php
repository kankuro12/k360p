<?php

namespace App\model\admin;

use Illuminate\Database\Eloquent\Model;

class Product_image extends Model
{
    //
    protected $primaryKey = 'product_image_id';
}
