<?php

namespace App\model\admin;

use Illuminate\Database\Eloquent\Model;

class Sell_product extends Model
{
    //
    protected $primaryKey = 'sell_product_id';
}
