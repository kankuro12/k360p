<?php

namespace App\model\admin;

use Illuminate\Database\Eloquent\Model;

class Stocks_status extends Model
{
    //
    protected $primaryKey = 'status_id';
}
