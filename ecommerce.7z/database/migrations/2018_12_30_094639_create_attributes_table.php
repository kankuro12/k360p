<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAttributesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('attributes', function (Blueprint $table) {
            $table->increments('attribute_id');
            $table->integer('attribute_group_id')->unsigned();
            //$table->foreign('attribute_group_id')->references('attribute_group_id')->on('attribute_groups')->onDelete('cascade');
            $table->string('attribute_name');
            $table->integer('attribute_status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('attributes');
    }
}
