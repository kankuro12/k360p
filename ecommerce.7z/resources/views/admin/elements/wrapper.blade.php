<div class="row">
    <div class="col-md-4">
        
        <a href="#" data-toggle="collapse" data-target="#section{id}" >
            <strong>{{name}}</strong>
        </a>
        ({{w}})
    </div>
    <div class="col-md-2">
        <strong>Rows : </strong>{{row}}
        
    </div>
    <div class="col-md-2">
        <strong>Order : </strong>{{order}}
    </div>
    <div class="col-md-4">
    <a href="#" onclick="showModal({{id}})"  >Add New</a>
    </div>
</div>

<div class="collapse" style="padding-left:100px;" id="section{{id}}">
    
</div>