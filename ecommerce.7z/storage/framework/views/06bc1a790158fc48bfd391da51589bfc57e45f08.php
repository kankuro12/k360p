
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 vendordetails">
                <h3 class="text-center" style="margin-top: 0px;">Store Order</h3>
                <br>
                <div class="nav-center">
                    <ul class="nav nav-pills nav-pills-primary nav-pills-icons">
                        <?php
                        $i=0;
                        ?>
                        <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li class="<?php echo e($i == $status ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('admin.orders', ['status' => $i])); ?>" aria-expanded="true">
                                    <i class="material-icons"><?php echo e(App\Setting\OrderManager::stageicons[$i]); ?></i><?php echo e($stage); ?>

                                </a>
                            </li>
                            <?php
                            $i+=1;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
                <div class="">
                    <div id="orders">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">
                                    <strong>
                                        <?php echo e(App\Setting\OrderManager::stages[$status]); ?> Orders
                                    </strong>
                                </h4>

                            </div>
                            <div class="card-content">
                                <div class="content-view">
                                    <div class="table-responsive">

                                        <table class="table">
                                            <tr>
                                                <th>SN</th>
                                                <th>Name</th>
                                                <th>Address</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Action</th>
                                            </tr>
                                            <?php
                                            $i=1;
                                            ?>
                                            <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo $__env->make('admin.order.ordergroup',['data'=>$data,'i'=>$i], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php
                                                $i+=1;
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- end col-md-12 -->
        </div>
        <!-- end row -->
    </div>
    <!-- Edit Attribute Modal -->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayouts.admin-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/admin/order/index.blade.php ENDPATH**/ ?>