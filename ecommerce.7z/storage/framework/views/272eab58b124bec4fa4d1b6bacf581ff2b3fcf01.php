
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">

                <div class="card" style="min-height: 200px;">
                    <div class="card-header card-header-icon" data-background-color="purple">
                        <i class="material-icons">assignment</i>
                    </div>
                    <div class="card-content">
                        <?php
                        $data=$section->getElement();
                        ?>
                        <h4 class="card-title"> <a href="<?php echo e(route('elements')); ?>"><strong>Homepage Section</strong></a>/
                            Boxed Item / <strong><?php echo e($section->name); ?></strong></h4>
                        <div>
                           
                        </div>
                        <div class="content-view">
                            <div id="root" style="padding:20px;border: #f1f1f1 1px solid;border-radius:10px;">
                              <form action="<?php echo e(route('elements.save-boxed',['section'=>$data->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <div class="row">
                                    
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label >
                                                <input type="checkbox" name="hascategory" id="hascategory" value="1"> Has Category
                                            </label>
                                            <select name="category_id" id="category_id" class="selectpicker " data-live-search="true"  data-style="btn btn-primary"
                                            title="Select A Category" data-size="6"  required>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->cat_id); ?>" ><?php echo e($item->cat_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label >
                                                Title
                                            </label>
                                           <input type="text" name="title" id="title" class="form-control" placeholder="Enter Title">
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                                <hr>
                                <div class="row">
                                  
                                    <div class="col-md-4">
                                        <label >Order By</label>
                                        <select name="orderby" id="orderby" class="form-control" required>
                                            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item); ?>" ><?php echo e($item); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label >Order </label>
                                        <select name="order" id="order" class="form-control" required>
                                            <option value="0" >Asc</option>
                                            <option value="1" >Desc</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label >No of Displayed Product</label>
                                        <input value="8" min="1" type="number" name="count" id="count" class="form-control" required>
                                    </div>
                                
                                </div>
                                <hr>
                                <div class="row">
                                    
                                    <div class="col-md-12">
                                        <label ><input type="checkbox" name="hasquery" id="hasquery" value="1"> Custom Query</label>
                                        <textarea name="mquery" id="query" cols="30" rows="10" style="width:100%;"></textarea>
                                    </div>
                                    <div class="col-md-12">
                                        <input type="submit" value="Add New Section" class="btn btn-primary">
                                    </div>
                                </div>
                            </form>
                            </div>
                            <br>
                            <?php $__currentLoopData = $data->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <div id="list" style="padding:20px;border: #f1f1f1 1px solid;border-radius:10px;">
                                <?php echo $__env->make('admin.elements.boxeddisplayitem',$item, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- end content-->
                    </div>
                    <!--  end card  -->
                </div>
                <!-- end col-md-12 -->
            </div>
            <!-- end row -->
        </div>
    </div>


    <!--Add Tag  Modal -->
    <?php echo $__env->make('admin.elements.section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayouts.admin-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/admin/elements/boxeddisplay.blade.php ENDPATH**/ ?>