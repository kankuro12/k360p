
<?php $__env->startSection('contant'); ?>
    <div class="row">
        <?php $__currentLoopData = App\model\admin\HomePageSection::where('parent_id', 0)->orderBy('order','asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-<?php echo e($item->row); ?> " id="section_<?php echo e($item->id); ?>">
                <?php echo $__env->make($item->render() ,['data'=>$item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.molla.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/themes/molla/home/app.blade.php ENDPATH**/ ?>