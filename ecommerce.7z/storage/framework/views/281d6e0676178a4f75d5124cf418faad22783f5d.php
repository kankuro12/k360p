
<?php $__env->startSection('content'); ?>
    <form method="POST">
        <?php echo csrf_field(); ?>
        <br>
        <div style="padding:25px;">

            <div class="row">

                <div class="col-md-12  ">
                    <div class="form-group label-floating">

                        <input type="text" class="form-control" placeholder="Landmark Near you " name="landmark"
                            id="landmark" required>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <label for="province_id">Select A province</label>
                        <select class="form-control" data-live-search="true" id="province_id" name="province_id"
                            data-style="btn btn-primary " title="Select a Province" data-size="7" required  style="border:1px solid #b6b6b6;">
                            <option></option>
                            <?php $__currentLoopData = \App\Province::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($province->id); ?>"><?php echo e($province->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="district_id">Select a District</label>

                    <select class="form-control" data-live-search="true" id="district_id" name="district_id"
                        data-style="btn btn-primary " title="Select a District" data-size="7" required style="border:1px solid #b6b6b6;">
                        <option> </option>

                    </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="municipality_id"> Select a Munucipality</label>

                    <select class="form-control" data-live-search="true" id="municipality_id" name="municipality_id"
                        data-style="btn btn-primary " title="Select Province" data-size="7" required style="border:1px solid #b6b6b6;">
                        <option> </option>

                    </select>
                </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="municipality_id">Select a Shipping Zone</label>

                    <select class="form-control" data-live-search="true" id="shipping_area_id" name="shipping_area_id"
                        data-style="btn btn-primary " title="Select Province" data-size="7" required style="border:1px solid #b6b6b6;">
                        <option></option>

                    </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="municipality_id">Select a Your Shipping Range</label>

                    <select class="form-control" data-live-search="true" id="deliver_range"
                        name="deliver_range" data-style="btn btn-primary " title="Select Province" data-size="7"
                        required style="border:1px solid #b6b6b6;">
                        <option> </option>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = \App\Setting\VendorOption::deliverrange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($item); ?></option>
                            <?php $i += 1; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                    </div>
                </div>
                <div class="col-md-3  ">
                    <div class="form-group label-floating">

                        <input type="checkbox" name="bulkbuy" id="bulkbuy" value="1"> Bulk Buy
                    </div>
                </div>
                <div class="col-md-3  ">
                    <div class="form-group label-floating">

                        <input type="checkbox" name="bulksell" id="bulksell" value="1"> Bulk Sell
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4"></div>
            <div class="col-md-4  text-center">
                <div class="form-group ">

                    <input type="submit" class="btn btn-danger" value="Next">
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        district = <?php echo \App\ District::all()->toJson(); ?>

        municipality = <?php echo \App\ Municipality::all()->toJson(); ?>

        area = <?php echo \App\ ShippingArea::all()->toJson(); ?>



        $('#province_id').change(function() {
            province_id = $('#province_id').val();

            str = "<option> </option>";
            district.forEach(element => {

                if (element.province_id == province_id) {

                    str += "<option value='" + element.id + "'>" + element.name + "</option>";
                }
            });
            $('#district_id').html(str);
            $('#municipality_id').html("<option> </option>");
            $('#shipping_area_id').html("<option> </option>");

        });
        $('#district_id').change(function() {
            district_id = $('#district_id').val();

            str = "<option></option>";
            municipality.forEach(element => {

                if (element.district_id == district_id) {

                    str += "<option value='" + element.id + "'>" + element.name + "</option>";
                }
            });

            $('#municipality_id').html(str);
            $('#shipping_area_id').html("<option> </option>");

        });
        $('#municipality_id').change(function() {
            municipality_id = $('#municipality_id').val();

            str = "<option> </option>";
            area.forEach(element => {

                if (element.municipality_id == municipality_id) {

                    str += "<option value='" + element.id + "'>" + element.name + "</option>";
                }
            });


            $('#shipping_area_id').html(str);

        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.step', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/vendor/auth/step2.blade.php ENDPATH**/ ?>