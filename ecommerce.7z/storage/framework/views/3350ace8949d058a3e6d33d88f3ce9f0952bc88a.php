
<?php $__env->startSection('content'); ?>
    <form method="POST">
        <?php echo csrf_field(); ?>
       <br>
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4  text-center">
                <div class="form-group ">
                    
                    <input type="text" required class="form-control text-center" name="code" placeholder="Enter Activation Code" >
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4"></div>
            <div class="col-md-4  text-center">
                <div class="form-group ">
                    
                    <input type="submit" class="btn btn-danger" value="Next">
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.step', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/vendor/auth/step1.blade.php ENDPATH**/ ?>