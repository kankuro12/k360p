<footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <ul>
                <li>
                    
                </li>
            </ul>
        </nav>
        <p class="copyright pull-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>
            <a href="http://www.needtechnosoft.com.np"> Need Technosoft </a>, made with love for a better Shopping Experience
        </p>
    </div>
</footer><?php /**PATH D:\New folder\ecommerce\resources\views/layouts/adminlayouts/admin-footer.blade.php ENDPATH**/ ?>