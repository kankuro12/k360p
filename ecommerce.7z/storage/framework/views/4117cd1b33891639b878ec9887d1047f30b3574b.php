
<?php $__env->startSection('content'); ?>
<?php
    $option=\App\model\admin\DefaultShipping::first();
?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">

                <div class="card">
                    <div class="card-header card-header-icon" data-background-color="rose">
                        <i class="material-icons">local_shipping</i>
                    </div>

                    <div class="card-content">
                        <h4 class="card-title">Manage Store Shipping Detail</h4>
                        <div>
                            
                            <form method="POST">
                            
                                <?php echo csrf_field(); ?>
                                <br>
                                <div style="padding:25px;">

                                    <div class="row">


                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="province_id">Select A province</label>
                                                <select class="form-control" data-live-search="true" id="province_id"
                                                    name="province_id" data-style="btn btn-primary "
                                                    title="Select a Province" data-size="7" required
                                                    style="border:1px solid #b6b6b6;">
                                                    <option></option>
                                                    <?php $__currentLoopData = \App\Province::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($province->id); ?>" ><?php echo e($province->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="district_id">Select a District</label>

                                                <select class="form-control" data-live-search="true" id="district_id"
                                                    name="district_id" data-style="btn btn-primary "
                                                    title="Select a District" data-size="7" required
                                                    style="border:1px solid #b6b6b6;">
                                                    <option> </option>

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="municipality_id"> Select a Munucipality</label>

                                                <select class="form-control" data-live-search="true" id="municipality_id"
                                                    name="municipality_id" data-style="btn btn-primary "
                                                    title="Select Province" data-size="7" required
                                                    style="border:1px solid #b6b6b6;">
                                                    <option> </option>

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="municipality_id">Select a Shipping Zone</label>

                                                <select class="form-control" data-live-search="true" id="shipping_area_id"
                                                    name="shipping_area_id" data-style="btn btn-primary "
                                                    title="Select Province" data-size="7" required
                                                    style="border:1px solid #b6b6b6;">
                                                    <option></option>

                                                </select>
                                            </div>
                                        </div>
                                       
                                      
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4"></div>
                                    <div class="col-md-4"></div>
                                    <div class="col-md-4  text-center">
                                        <div class="form-group ">

                                            <input type="submit" class="btn btn-primary" value="Save Store Shipping Detail">
                                        </div>
                                    </div>
                                </div>
                               
                            </form>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        district = <?php echo \App\ District::all()->toJson(); ?>

        municipality = <?php echo \App\ Municipality::all()->toJson(); ?>

        area = <?php echo \App\ ShippingArea::all()->toJson(); ?>



        $('#province_id').change(function() {
            province_id = $('#province_id').val();

            str = "<option> </option>";
            district.forEach(element => {

                if (element.province_id == province_id) {

                    str += "<option value='" + element.id + "'>" + element.name + "</option>";
                }
            });
            $('#district_id').html(str);
            $('#municipality_id').html("<option> </option>");
            $('#shipping_area_id').html("<option> </option>");

        });
        $('#district_id').change(function() {
            district_id = $('#district_id').val();

            str = "<option></option>";
            municipality.forEach(element => {

                if (element.district_id == district_id) {

                    str += "<option value='" + element.id + "'>" + element.name + "</option>";
                }
            });

            $('#municipality_id').html(str);
            $('#shipping_area_id').html("<option> </option>");

        });
        $('#municipality_id').change(function() {
            municipality_id = $('#municipality_id').val();

            str = "<option> </option>";
            area.forEach(element => {

                if (element.municipality_id == municipality_id) {

                    str += "<option value='" + element.id + "'>" + element.name + "</option>";
                }
            });


            $('#shipping_area_id').html(str);

        });
        <?php if($option!=null): ?>
        $( document ).ready(function() {
            $("#province_id").val(<?php echo e($option->province_id); ?>).change();
            $("#district_id").val(<?php echo e($option->district_id); ?>).change();
            $("#municipality_id").val(<?php echo e($option->municipality_id); ?>).change();
            $("#shipping_area_id").val(<?php echo e($option->shipping_area_id); ?>).change();
        });
        <?php endif; ?>


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayouts.admin-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/admin/shipping/address.blade.php ENDPATH**/ ?>