
<?php $__env->startSection('content'); ?>
    <?php
        $v=$vendor->verified!=1;
    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">

                <div class="card">
                    <div class="card-header card-header-icon" data-background-color="rose">
                        <i class="material-icons">beenhere</i>
                    </div>

                    <div class="card-content">
                        <h4 class="card-title"><?php echo e($v?"Edit ":"View "); ?> Verification Detail</h4>
                        <div>
                            <?php if($v): ?>
                                
                            <form method="POST" enctype="multipart/form-data">
                            <?php endif; ?>
                                <?php echo csrf_field(); ?>
                                <br>
                                <div style="padding:25px;">
                        
                                    <div class="row">
                        
                                        <div class="col-md-6  ">
                                            <div class="form-group label-floating">
                                                <label for="bankname">Bank Name</label>
                                                <input type="text" class="form-control" placeholder="Bank Name" name="bankname" id="bankname"
                                                    required value="<?php echo e($verification->bankname); ?>" <?php echo e(!$v?"readonly":""); ?>>
                                            </div>
                                        </div>
                                        <div class="col-md-6  ">
                                            <div class="form-group label-floating">
                                                <label for="bankaccount">Bank Account no</label>
                                                <input type="text" class="form-control" placeholder="Bank Account" name="bankaccount"
                                                    id="bankaccount" required value="<?php echo e($verification->bankaccount); ?>" <?php echo e(!$v?"readonly":""); ?>>
                                            </div>
                                        </div>
                        
                                        <div class="col-md-6  ">
                                            <div class="form-group label-floating">
                                                <div>
                                                    <h3>
                                                        Registration Document
                                                    </h3>
                                                </div>
                                                <div style="position: relative">
                                                    <div>
                                                        <?php if($v): ?>
                                                            
                                                        <input onchange="loadImage(this)" style="display:none;" name="image" type="file" id="gal"
                                                        accept="image/*"  />
                                                        <?php endif; ?>
                                                        <img src="<?php echo e(asset($verification->registration)); ?>" alt="..." id="gal_img"
                                                            onclick="document.getElementById('gal').click();" style="width: 100%;">
                                                    </div>
                                                    <?php if($v): ?>
                                                        
                                                    <div style="position: absolute;top:0px;right:0px;">
                                                        <span class="btn btn-danger" onclick="
                                                                                            document.getElementById('gal').value = null;
                                                                                            document.getElementById('gal_img').src='<?php echo e(asset($verification->registration)); ?>';
                                                                                            ">Clear</span>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                        
                                        <div class="col-md-6  ">
                                            <div class="form-group label-floating">
                                                <div>
                                                    <h3>
                                                       citizenship
                                                    </h3>
                                                </div>
                                                <div style="position: relative">
                                                    <div>
                                                        <?php if($v): ?>
                                                            
                                                        <input onchange="loadImage1(this)" style="display:none;" name="image1" type="file" id="gal1"
                                                            accept="image/*"  />
                                                        <?php endif; ?>
                                                        <img src="<?php echo e(asset($verification->citizenship)); ?>" alt="..." id="gal_img1"
                                                            onclick="document.getElementById('gal1').click();" style="width: 100%;">
                                                    </div>
                                                    <?php if($v): ?>
                                                        
                                                    <div style="position: absolute;top:0px;right:0px;">
                                                        <span class="btn btn-danger" onclick="
                                                                                            document.getElementById('gal1').value = null;
                                                                                            document.getElementById('gal_img1').src='<?php echo e(asset($verification->citizenship)); ?>';
                                                                                            ">Clear</span>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                        
                        
                                    </div>
                                </div>
                        
                                <div class="row">
                                    <div class="col-md-4"></div>
                                    <div class="col-md-4"></div>
                                    <div class="col-md-4  text-center">
                                        <div class="form-group ">
                                            <?php if($v): ?>
                                                
                                                <input type="submit" class="btn btn-danger" value="Save">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php if($v): ?>
                                    
                            </form>
                                <?php endif; ?>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
   <?php if($v): ?>
   <script>
    function loadImage(input) {
        console.log(input);
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                $('#gal_img').attr('src', e.target.result);
            }
            var FileSize = input.files[0].size / 1024;
            if (FileSize > 3072) {
                alert('Image Size Cannot Be Greater than 3mb');
                document.getElementById('gal_img').src = '<?php echo e(asset($verification->registration)); ?>';
                input.value = null;
                console.log(input.files);
            } else {

                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }
    }

    function loadImage1(input) {
        console.log(input);
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                $('#gal_img1').attr('src', e.target.result);
            }
            var FileSize = input.files[0].size / 1024;
            if (FileSize > 3072) {
                alert('Image Size Cannot Be Greater than 3mb');
                document.getElementById('gal_img1').src = '<?php echo e(asset($verification->citizenship)); ?>';
                input.value = null;
                console.log(input.files);
            } else {

                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }
    }
</script>
   <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sellerlayouts.seller-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/vendor/auth/verification.blade.php ENDPATH**/ ?>