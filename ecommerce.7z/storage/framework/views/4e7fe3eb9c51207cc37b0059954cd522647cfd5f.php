<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Multi Ecom::Seller Registration</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="<?php echo e(asset('css/backend-css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('fonts/iconic/css/material-design-iconic-font.min.css')); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <style>
            .formwrap{
                margin-top: 10px;
                text-align: center;
                font-weight: bold;
            }
            #load:disabled{
                opacity:0.7;
                cursor: not-allowed;
            }
        </style>
	</head>

	<body>

		<div class="wrapper" style="background-image: url('/images/bg-1.jpg');">
			<div class="inner">
				<div class="image-holder">
					<img src="<?php echo e(asset('images/bg6.jpg')); ?>" alt="">
				</div>
				<form id="register-form" action="<?php echo e(route('vendor.postRegister')); ?>" method="POST">
                    <h3>Seller Registration</h3>
                    <div id="statusBox">
                    </div>
                    <?php echo csrf_field(); ?>
					<div class="form-wrapper">
                        <input type="text" name="vname" id="vname" placeholder="Seller Name" class="form-controla" required>
                        <i class="zmdi zmdi-account"></i>
					</div>
					<div class="form-wrapper">
						<input type="email" name="email" id="email" placeholder="Email Address" class="form-controla" required>
						<i class="zmdi zmdi-email"></i>
                    </div>
                    <div class="form-wrapper">
						<input type="text" name="phone_number" id="phone_number" placeholder="Phone Number" required class="form-controla">
						<i class="zmdi zmdi-phone"></i>
					</div>
					<div class="form-wrapper">
						<input type="password" placeholder="Password" name="password" id="password" class="form-controla" required>
						<i class="zmdi zmdi-lock"></i>
					</div>
					<div class="form-wrapper">
						<input type="password" name="password_confirmation" id="cpassword" placeholder="Confirm Password" class="form-controla" required>
						<i class="zmdi zmdi-lock"></i>
                    </div>
                    <div class="form-wrapper">
                        <input type="checkbox" name="agreetc" id="agreetc" value="1">
                        <label for="agreetc" class="color-secondary">I agree to the <a href="/terms-and-conditions" class="color-primary">Terms and conditions</a></label>
                    </div>
					<button id="load">Register
						<i class="zmdi zmdi-arrow-right"></i>
                    </button>
                    <div class="formwrap">
                            <p class="color-secondary text-center font-weight-bold">Already a member ? <a href="<?php echo e(route('vendor.getLogin')); ?>" class="color1">Sign in</a></p>
                    </div>
				</form>
			</div>
        </div>
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    
</html><?php /**PATH D:\New folder\ecommerce\resources\views/vendor/auth/register.blade.php ENDPATH**/ ?>