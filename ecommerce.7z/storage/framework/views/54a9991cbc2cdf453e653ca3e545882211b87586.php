<div>
    <?php
        $product=$order->product;

    ?>
    <div class="card" style="margin: 5px 0;padding: 10px;">
        <div class="row">
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-3 text-right"> <strong>Name</strong> </div>
                    <div class="col-md-9"><?php echo e($product->product_name); ?></div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-3 text-right"> <strong>Quantity</strong> </div>
                    <div class="col-md-3"><?php echo e($order->qty); ?></div>
                    <div class="col-md-3 text-right"> <strong>Rate</strong> </div>
                    <div class="col-md-3"><?php echo e($order->rate); ?></div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-3 text-right"> <strong>Quantity</strong> </div>
                    <div class="col-md-3"><?php echo e($order->qty); ?></div>
                   
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\New folder\ecommerce\resources\views/admin/order/singleorder.blade.php ENDPATH**/ ?>