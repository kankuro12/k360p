<div id="s_<?php echo e($data->id); ?>">
   
    <div class="row">
        <div class="col-md-4">
            <?php if($data->type == 0): ?>
                <a href="#" data-toggle="collapse" data-target="#section<?php echo e($data->id); ?>">
                    <strong id="sec_<?php echo e($data->id); ?>_name"> <?php echo e($data->name); ?></strong>
                </a>
            <?php else: ?>
                <strong id="sec_<?php echo e($data->id); ?>_name"><?php echo e($data->name); ?></strong>
            <?php endif; ?>
            (<?php echo e(\App\Setting\Homepage::sectiontype[$item->type]); ?>)
        </div>
        <div class="col-md-2">
            <strong>Rows : </strong> 
            <span id="sec_<?php echo e($data->id); ?>_row">
                <?php echo e($data->row); ?>

            </span>

        </div>
        <div class="col-md-2">
            <strong>Order : </strong>
            <span id="sec_<?php echo e($data->id); ?>_order">
                <?php echo e($data->order); ?>

            </span>
        </div>
        <div class="col-md-4">
            <?php if($data->type == 0): ?>
                <a href="#" onclick="showModal(<?php echo e($data->id); ?>)">Add New</a>
            <?php else: ?>
                <a href="<?php echo e(route('elements.manage',['section'=>$data->id])); ?>" target="_blank">Manage</a>
            <?php endif; ?>
            | <a href="#"  onclick="del(<?php echo e($data->id); ?>)">Del</a>
            | <a href="#"  onclick="edit(<?php echo e($data->id); ?>)">Edit</a>
        </div>
    </div>

    <hr>

    <?php if($data->type == 0): ?>
        <div class="collapse" style="padding-left:100px;" id="section<?php echo e($data->id); ?>">
            <?php if($data->childCount() > 0): ?>
                <?php $__currentLoopData = $data->child(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('admin.elements.child',['data'=>$pdata], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH D:\New folder\ecommerce\resources\views/admin/elements/child.blade.php ENDPATH**/ ?>