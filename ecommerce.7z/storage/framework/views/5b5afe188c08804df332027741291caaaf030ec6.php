
<?php $__env->startSection('content'); ?>
    <?php
    $sel=0;
    if(session('sel')){
    $sel=session('sel');
    }
    ?>
    <br>
    <div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
    <br>
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12">

                <?php if(Session::has('flash_message')): ?>
                    <div class="alert alert-success">
                        <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                            <i class="tim-icons icon-simple-remove"></i>
                        </button>
                        <span>
                            <b> Success - </b><?php echo session('flash_message'); ?></span>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header card-header-icon" data-background-color="purple">
                        <i class="material-icons">local_shipping</i>
                    </div>
                    <div class="card-content">
                        <h4 class="card-title">
                            <a href="<?php echo e(route('admin.shippings')); ?>"> <strong>Shippings</strong> </a>
                            /
                            <?php echo e($shipping->name); ?>

                            /
                            <a href="<?php echo e(route('admin.manage-category')); ?>"> <strong>Categories</strong> </a> 
                            /
                            <?php echo e($category->cat_name); ?>

                        </h4>
                        <div class="toolbar">
                            <!--        Here you can write extra buttons/actions for the toolbar              -->
                        </div>
                        <div class="content-view">
                            <div class="nav-center">
                                <ul class="nav nav-pills nav-pills-primary nav-pills-icons" role="tablist">
                                    <?php $i = 0; ?>
                                    <?php $__currentLoopData = \App\Setting\VendorOption::deliverrange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li class="<?php echo e($i == $sel ? 'active' : ''); ?>">
                                            <a href="#area_<?php echo e($i); ?>" role="tab" data-toggle="tab" aria-expanded="true">
                                                <?php echo e($range); ?>

                                            </a>
                                        </li>
                                        <?php $i += 1; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $i = 0; ?>

                                </ul>
                            </div>
                            <div class="tab-content">
                                <?php $i = 0; ?>
                                <?php $__currentLoopData = \App\Setting\VendorOption::deliverrange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tab-pane <?php echo e($i == $sel ? 'active' : ''); ?>" id="area_<?php echo e($i); ?>"
                                        style="min-height: 40vh;">
                                        <form action="<?php echo e(route('admin.shipping-weight')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <input type="hidden" name="deliver_range" value="<?php echo e($i); ?>">
                                                <input type="hidden" name="category_id" value="<?php echo e($category->cat_id); ?>">
                                                <input type="hidden" name="shipping_class_id" value="<?php echo e($shipping->id); ?>">
                                                <div class="col-md-6">
                                                    <div class="form-group">

                                                        <select required class="selectpicker" data-live-search="true"
                                                            id="p_<?php echo e($i); ?>" name="type" data-style="btn btn-primary"
                                                            title="Select A price Type" data-size="6">
                                                            <?php $__currentLoopData = \App\Setting\VendorOption::shippingoption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">

                                                        <label for="amount">Price</label>
                                                        <input required placeholder="Enter Price" type="number"
                                                            name="amount" id="amount" class="form-control" step="0.01">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">

                                                        <label required for="min">Minimum Weight</label>
                                                        <input placeholder="Enter Minimim Weight" type="number" name="min"
                                                            id="min" class="form-control" step="0.01" min="0">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label required for="max">Minimum Weight</label>
                                                        <input type="number" placeholder="Enter Maximum Weight" name="max"
                                                            id="max" class="form-control" step="0.01" min="0">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <input type="submit" value="Save Weight" class="btn btn-primary">
                                                    </div>
                                                </div>

                                            </div>
                                        </form>
                                        <br>
                                        <div class="table-responsive">
                                            <table class="table">
                                                <tr>
                                                    <th></th>
                                                    <th class="th-description">Weight Class</th>
                                                    <th>Type</th>
                                                    <th>Price</th>
                                                    <th colspan="2">Actions</th>
                                                </tr>
                                                <?php $__currentLoopData = \App\WeightClass::where('category_id', $category->cat_id)->where('deliver_range', $i)->where('shipping_class_id', $shipping->id)->orderBy('min', 'asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <form action="<?php echo e(route('admin.shipping-weight-update', ['wc' => $wc->id])); ?>" method="post">
                                                        <td></td>
                                                        <?php echo csrf_field(); ?>
                                                        <td class="td-name">
                                                            <input type="number" name="min" id="min" required step="0.01"
                                                                value="<?php echo e($wc->min); ?>" style="width:100px;">
                                                            <?php echo e($shipping->weightclass); ?> -
                                                            <input type="number" name="max" id="max" required step="0.01"
                                                                value="<?php echo e($wc->max); ?>" style="width:100px;">
                                                            <?php echo e($shipping->weightclass); ?></td>
                                                        <td>
                                                            <select required name="type" >
                                                                <?php $__currentLoopData = \App\Setting\VendorOption::shippingoption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($key); ?>" <?php echo e($key==$wc->type?"selected":""); ?>><?php echo e($item); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            
                                                        </td>
                                                        <td>
                                                            <input type="number" name="amount" id="amount" required step="0.01"
                                                                value="<?php echo e($wc->amount); ?>" style="width:100px;">
                                                            
                                                            </td>
                                                            <td>
                                                                <input type="submit" value="Update" class="btn btn-primary">
                                                            </td>
                                                        </form>
                                                        <td>
                                                            <form action="<?php echo e(route('admin.shipping-weight-del',['wc' => $wc->id])); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                 <input type="submit" value="Delete" class="btn btn-danger">
 
                                                             </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </table>
                                        </div>
                                    </div>
                                    <?php $i += 1; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $i = 0; ?>
                                <br>

                            </div>
                        </div>
                    </div>
                    <!-- end content-->
                </div>
                <!--  end card  -->
            </div>
            <!-- end col-md-12 -->
        </div>
        <!-- end row -->
    </div>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayouts.admin-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/admin/shipping/manage.blade.php ENDPATH**/ ?>