<div>
    <form action="<?php echo e(url('vendor/product-option/' . $productdetail->product_id)); ?>" method="post">
        <?php

        $option=$productdetail->option();

        ?>
        <?php echo csrf_field(); ?>

        <div>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for=""> Warrenty Type</label>
                        <select class="selectpicker" title="Select a Warranty type" class="form-control" type="text"
                            name="warrenty" id="warrenty">
                            <?php $__currentLoopData = \App\Setting\ProductManager::warrenty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $warrenty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"
                                    <?php echo e($option != null ? ($option->warrenty == $key ? 'selected' : '') : ''); ?>>
                                    <?php echo e($warrenty); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                </div>


                <div class="col-md-4">
                    <label for=""> Warrenty Period</label>

                    <input placeholder="Enter Period" class="form-control" type="number" name="warrentyperiod"
                        id="warrentyperiod" min="0" value="<?php echo e($option != null ? $option->warrentyperiod:''); ?>">
                </div>
                <div class="col-md-4">
                    <label for=""> Warrenty Period Type</label>

                    <select class="selectpicker" title="Select a Period type" class="form-control" type="text"
                        name="	warrentytime" id="	warrentytime">
                        <option value="Day"   <?php echo e($option != null ? ($option->warrentytime == 'Day' ? 'selected' : '') : ''); ?>>Day</option>
                        <option value="Month"  <?php echo e($option != null ? ($option->warrentytime == 'Month' ? 'selected' : '') : ''); ?>>Month</option>
                        <option value="Year" <?php echo e($option != null ? ($option->warrentytime == 'Year' ? 'selected' : '') : ''); ?>>Year</option>

                    </select>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label for=""><input type="checkbox" name="isrefundable" id="isrefundable"  <?php echo e($option != null ? ($option->isrefundable?'checked' : '') : ''); ?> value="1"> Refundable 
                        </label>
                        <hr>
                        <label >
                            Refundable Policy
                        </label>   
                        <textarea class="form-control" name="refundablepolicy" id="refundablepolicy"><?php echo e($option != null ? $option->refundablepolicy : ''); ?></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <button class="btn btn-primary">Save Product Options</button>
        </div>
    </form>
</div>
<?php /**PATH D:\New folder\ecommerce\resources\views/vendor/product/detail.blade.php ENDPATH**/ ?>