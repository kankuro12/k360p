
<?php $__env->startSection('content'); ?>
<?php
    $sel=1;
    if(session('sel')){
        $sel=session('sel');
    }
?>
    <div class="container-fluid">

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <br>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-icon" data-background-color="rose">
                        <i class="material-icons">card_giftcard
                        </i>
                    </div>
                    <div class="card-header">
                        <h4 class="card-title">
                            Packaging Charges
                        </h4>
                        
                    </div>
                    <div class="card-content">
                        <br>
                        <form action="<?php echo e(route('admin.packaging-add')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <label >Lower value</label>
                                    <input required type="text" name="name" id="name" 
                            class="form-control" placeholder="Enter name">
                                </div>
                                
                                <div class="col-md-6">
                                    <label >Rate</label>
                                    <input  required  type="number" step="0.01" min="0" name="amount" id="amount" 
                            class="form-control" placeholder="Enter Rate">
                                </div>
                                
                                <div class="col-md-6">
                                    <input type="submit" value="Add New" class="btn btn-primary">
                                </div>
                            </div>
                        </form>
                        <hr>
                        <h4>
                            <strong>Packaging Charges</strong>
                        </h4>
                        <table class="table">
                            <tr>
                                <th></th>
                                <th>Name</th>
                                <th>Rate</th>
                             
                                <th colspan="2"></th>
                            </tr>
                            <?php $__currentLoopData = \App\PackagingCharge::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packaging): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <form action="<?php echo e(route('admin.packaging-update',['packaging'=>$packaging->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                    <td></td>
                                <td>  <input required type="text"  name="name" id="name" 
                                    class="form-control" placeholder="Enter Name" value="<?php echo e($packaging->name); ?>"></td>
                              
                                <td> <input  required  type="number" step="0.01" min="0" name="amount" id="amount" 
                                    class="form-control" placeholder="Enter Rate" value="<?php echo e($packaging->amount); ?>"></td>
                                <td >
                                    <input type="submit" value="Update" class="btn btn-primary">
                                </td>
                                </form>
                                <td >
                                    <form action="<?php echo e(route('admin.packaging-del',['packaging'=>$packaging->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="submit" value="Delete" class="btn btn-danger">

                            </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    


<?php $__env->stopSection(); ?> 
<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayouts.admin-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/admin/charges/packaging.blade.php ENDPATH**/ ?>