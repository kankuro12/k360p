<?php
    $shipping=$data['shipping'];
?>
<tr>
    <td ><?php echo e($i); ?></td>
    <td>
        <?php echo e($shipping->name); ?>

    </td>
    <td>
        <?php echo e($shipping->area->name); ?>,<br>  <?php echo e($shipping->municipality->name); ?>,<br> <?php echo e($shipping->district->name); ?>, <?php echo e($shipping->province->name); ?>

    </td>
    <td>
        <?php echo e($shipping->email); ?>

    </td>
    <td>
        <?php echo e($shipping->phone); ?>

    </td>
    <td>
        <?php echo e($data['count']); ?>  Items
        <br>
        <a data-toggle="collapse" href="#order-<?php echo e($shipping->id); ?>" aria-expanded="false" aria-controls="collapseExample">
            View Items
          </a>
    </td>
</tr>

<tr>
    <td colspan="6">
        <div class="collapse" id="order-<?php echo e($shipping->id); ?>">
            <?php $__currentLoopData = $data['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div >
                   <?php echo $__env->make('admin.order.singleorder',$order, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
    </td>
</tr><?php /**PATH D:\New folder\ecommerce\resources\views/admin/order/ordergroup.blade.php ENDPATH**/ ?>