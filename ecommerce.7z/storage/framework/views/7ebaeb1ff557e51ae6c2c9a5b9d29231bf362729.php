
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">

                <div class="card" style="min-height: 200px;">
                    <div class="card-header card-header-icon" data-background-color="purple">
                        <i class="material-icons">assignment</i>
                    </div>
                    <div class="card-content">
                        <?php
                        $data=$section->getElement();
                        ?>
                        <h4 class="card-title"> <a href="<?php echo e(route('elements')); ?>"><strong>Homepage Section</strong></a>/
                            Slider / <strong><?php echo e($section->name); ?></strong></h4>
                        <div>
                            <a class="btn btn-primary" href="<?php echo e(route('elements.add-slider', ['group' => $data->id])); ?>">Add
                                New Slider</a>
                        </div>
                        <div class="content-view">
                            <div id="root">
                                <?php $__currentLoopData = $data->sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <img src="<?php echo e(asset($slider->slider_image)); ?>" alt="" srcset=""
                                                style="width: 100%;">
                                        </div>
                                        <div class="col-md-6">
                                            <table class="table">
                                                <tr>
                                                    <td>
                                                        <strong>Primary Text</strong>
                                                    </td>
                                                    <td>
                                                        <?php echo e($slider->primary_text); ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <strong>Secondary Text</strong>
                                                    </td>
                                                    <td>
                                                        <?php echo e($slider->secondary_text); ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <strong>Button Text</strong>
                                                    </td>
                                                    <td>
                                                        <?php echo e($slider->button_text); ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <strong>link Text</strong>
                                                    </td>
                                                    <td>
                                                        <a target="_blank"
                                                            href="<?php echo e($slider->link_text); ?>"><?php echo e($slider->link_text); ?></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2">
                                                        <form
                                                            action="<?php echo e(route('elements.del-slider', ['slider' => $slider->id])); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="submit" value="Delete" class="btn btn-danger">
                                                        </form>
                                                    </td>
                                                </tr>
                                            </table>
                                            <hr>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                        <!-- end content-->
                    </div>
                    <!--  end card  -->
                </div>
                <!-- end col-md-12 -->
            </div>
            <!-- end row -->
        </div>
    </div>


    <!--Add Tag  Modal -->
    <?php echo $__env->make('admin.elements.section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayouts.admin-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/admin/elements/slider.blade.php ENDPATH**/ ?>