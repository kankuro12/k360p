
<?php $__env->startSection('title','User Dashboard'); ?>
<?php $__env->startSection('contant'); ?>
<main class="main">
    <div class="page-header text-center" style="background-image: url('themes/molla/assets/images/page-header-bg.jpg')">
        <div class="container">
            <h1 class="page-title">My Account<span>Shop</span></h1>
        </div><!-- End .container -->
    </div><!-- End .page-header -->
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Shop</a></li>
                <li class="breadcrumb-item active" aria-current="page">My Account</li>
            </ol>
        </div><!-- End .container -->
    </nav><!-- End .breadcrumb-nav -->

    <div class="page-content">
        <div class="dashboard">
            <div class="container">
                <div class="row">
                   <?php echo $__env->make('themes.molla.user.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php
                      $user = \App\model\VendorUser\VendorUser::where('user_id',Auth::user()->id)->first();
                    ?>
                    <div class="col-md-8 col-lg-9">
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="tab-dashboard" role="tabpanel" aria-labelledby="tab-dashboard-link">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="card card-dashboard">
                                            <div class="card-body">
                                                <h3 class="card-title">User Info</h3><!-- End .card-title -->
                                                <p><?php echo e($user->fname); ?> <?php echo e($user->lname); ?><br>
                                                    <?php echo e($user->mobile_number); ?><br>
                                                    <?php echo e($user->user->email); ?><br>
                                                    <?php echo e($user->province); ?><br>
                                                    <?php echo e($user->city); ?><br>
                                                    <?php echo e($user->postalcode); ?> : Postalcode<br>
                                                    <?php echo e($user->dob); ?><br>
                                                    <?php echo e($user->gender); ?><br>
                                                </p>
                                            </div><!-- End .card-body -->
                                        </div><!-- End .card-dashboard -->

                                    </div>
                                    <div class="col-md-3">
                                        <img src="<?php echo e(asset($user->profile_img)); ?>" alt="user_image" class="img-thumbnail">
                                    </div>
                                </div>
                            </div><!-- .End .tab-pane -->
                        </div>
                    </div><!-- End .col-lg-9 -->
                </div><!-- End .row -->
            </div><!-- End .container -->
        </div><!-- End .dashboard -->
    </div><!-- End .page-content -->
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.molla.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/themes/molla/user/dashboard/index.blade.php ENDPATH**/ ?>