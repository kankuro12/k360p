<div>
    <form action="<?php echo e(route('admin.admin-charge',['product'=>$productdetail->product_id])); ?>" method="post">
    <?php echo csrf_field(); ?>
    <table class="table">
        <tr>
            <td>
                <strong>Referal Charge</strong>
            </td>
            <td>
                <input type="number" name="rc" id="rc" class="form-control" min="0" value="<?php echo e($productdetail->referalcharge); ?>">
            </td>
        </tr>
        <tr>
            <td>
                <strong>Closing Charge</strong>
            </td>
            <td>
                <input type="number" name="cc" id="cc" class="form-control" min="0" value="<?php echo e($productdetail->closingcharge); ?>">
            </td>
        </tr>
        <tr>
            <td>
                <strong>Packaging Charge</strong>
            </td>
            <td>
                <input type="number" name="pc" id="pc" class="form-control" min="0" value="<?php echo e($productdetail->packagingcharge); ?>">
            </td>
        </tr>
        <tr>
            <td>
                <input type="submit" value="Save Charges" class="btn btn-primary">
            </td>
        </tr>
    </table>
    </form>
</div><?php /**PATH D:\New folder\ecommerce\resources\views/admin/product/admincharges.blade.php ENDPATH**/ ?>