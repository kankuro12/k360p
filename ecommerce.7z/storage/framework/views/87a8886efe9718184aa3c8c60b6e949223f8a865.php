<div class="row">
    <?php $__currentLoopData = App\model\admin\HomePageSection::where('parent_id', $data->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-<?php echo e($item_1->row); ?> order-md-<?php echo e($item_1->order); ?> pt-1" id="section_<?php echo e($item_1->id); ?>">
            <?php echo $__env->make($item_1->render() ,['data'=>$item_1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH D:\New folder\ecommerce\resources\views/themes/molla/elements/wrapper.blade.php ENDPATH**/ ?>