
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
        <div class="col-md-12">
            <h3><?php echo e($collectionname); ?></h3>
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="purple">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">Products</h4>
                    <div class="collection-images">
                        <img src="<?php echo e(asset('images/backend_images/collections/'.$collectionimage)); ?>" alt="">
                    </div>
                    <div class="content-view">
                    <div class="material-datatables">
                        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Product Code</th>
                                    <th>Name</th>
                                    <th>Mark Price</th>
                                    <th>Sell Price</th>
                                    <th class="disabled-sorting text-right">Actions</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Product Code</th>
                                    <th>Name</th>
                                    <th>Mark Price</th>
                                    <th>Sell Price</th>
                                    <th class="text-right">Actions</th>
                                </tr>
                            </tfoot>
                            <tbody>
                               
                                <?php $no=1; ?>
                                <?php $__currentLoopData = $abc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="product<?php echo e($ab->product_id); ?>">
                                <?php echo csrf_field(); ?>
                                    <td><?php echo e($ab->product_code); ?></td>
                                    <td><?php echo e($ab->product_name); ?></td>
                                    <td><?php echo e($ab->mark_price); ?></td>
                                    <td><?php echo e($ab->sell_price); ?></td>
                                    <td class="text-right">
                                       <button class=" delete btn btn-danger" onClick="remove(this)" data-id="<?php echo e($ab->product_id); ?>" data-collection="<?php echo e($ab->collection_id); ?>">Remove</button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
                <!-- end content-->
            </div>
            <!--  end card  -->
        </div>
        <!-- end col-md-12 -->
    </div>
    <!-- end row -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
function remove(p){
    var productid = p.dataset.id;
    var collectionid = p.dataset.collection;
    $.ajax({
        type: 'post',
        url: '/admin/delete-collection-product',
        data:{ '_token': $('input[name=_token]').val(), 'collection_id' : collectionid, 'product_id' : productid },
        success: function(data){
            $('.product'+productid).remove();
        },

    });
    console.log(collectionid);
}

$(document).ready(function(){

});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayouts.admin-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/admin/editproductcollection.blade.php ENDPATH**/ ?>