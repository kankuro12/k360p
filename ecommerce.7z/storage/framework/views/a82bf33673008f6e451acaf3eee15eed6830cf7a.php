<div>
    <form action="<?php echo e(route('admin.simpe-stock',['product'=>$productdetail->product_id])); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-12">
            <label >
                Quantity
            </label>
            <input type="number" name="qty" value="<?php echo e($productdetail->quantity); ?>" min="0" step="0.01" class="form-control">
        </div>
        <div class="col-md-12">
            <input type="submit" value="Update Stock" class="btn btn-primary">
        </div>
    </div>
    </form>
</div><?php /**PATH D:\New folder\ecommerce\resources\views/admin/product/SimpleStock.blade.php ENDPATH**/ ?>