
<?php $__env->startSection('content'); ?>

    <br>
    <div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
    <br>
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12">

                <?php if(Session::has('flash_message')): ?>
                    <div class="alert alert-success">
                        <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                            <i class="tim-icons icon-simple-remove"></i>
                        </button>
                        <span>
                            <b> Success - </b><?php echo session('flash_message'); ?></span>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header card-header-icon" data-background-color="purple">
                        <i class="material-icons">local_shipping</i>
                    </div>
                    <div class="card-content">
                        <h4 class="card-title"><a href="<?php echo e(route('admin.shippings')); ?>">Shippings</a> /
                            <?php echo e($shipping->name); ?></h4>
                        <div class="toolbar">
                            <!--        Here you can write extra buttons/actions for the toolbar              -->
                        </div>
                        <div class="content-view">
                            <table class="table">
                                <thead>

                                    <tr>
                                        <th>Category Name</th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = \App\model\admin\Category::whereNull('parent_id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($category->cat_name); ?></td>
                                            <td>
                                                <a
                                                    href="<?php echo e(url('admin/shippings/manage/' . $shipping->id . '/category/' . $category->cat_id)); ?>">
                                                    Manage Shipping
                                                </a>
                                            </td>
                                            <td>
                                                <a
                                                    href="<?php echo e(url('admin/shippings/manage/' . $shipping->id . '/subcat/' . $category->id)); ?>">SubCategories</a>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- end content-->
                </div>
                <!--  end card  -->
            </div>
            <!-- end col-md-12 -->
        </div>
        <!-- end row -->
    </div>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayouts.admin-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/admin/shipping/category.blade.php ENDPATH**/ ?>