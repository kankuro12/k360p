<div>
    <form action="<?php echo e(url('admin/product-shipping/' . $productdetail->product_id)); ?>" method="post">
        <?php

            $shipping=$productdetail->shipping();

        ?>
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-12">
                <label for="">Shipping Method</label>
                <select class="selectpicker" data-live-search="true" id="shipping_class_id" name="shipping_class_id"
                    data-style="btn btn-primary " title="Select A shipping Method" data-size="3" required onchange="
                    $('#w_class').text($(this).find(':selected').attr('data-wclass'));
                    $('.d_class').text($(this).find(':selected').attr('data-dclass'));
                    ">
                    <?php $__currentLoopData = App\ShippingClass::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option  data-wclass="<?php echo e($item->weightclass); ?>" data-dclass="<?php echo e($item->dimensionclass); ?>" value="<?php echo e($item->id); ?>" <?php echo e($shipping!=null?($shipping->shipping_class_id==$item->id?'selected':''):''); ?>>
                            <?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>

        </div>
        <div >
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for=""> Weight <span id="w_class"><?php echo e($shipping!=null?$shipping->shipping->weightclass:""); ?></span></label>
                        <input required type="number" step="0.01" name="weight" class="form-control" value="<?php echo e($shipping!=null?$shipping->weight:""); ?>">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for=""> Length <span class="d_class"><?php echo e($shipping!=null?$shipping->shipping->dimensionclass:""); ?></span></label>
                        <input required type="number" step="0.01" name="l" class="form-control" value="<?php echo e($shipping!=null?$shipping->l:""); ?>">

                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for=""> Height <span class="d_class"><?php echo e($shipping!=null?$shipping->shipping->dimensionclass:""); ?></span></label>
                        <input required type="number" step="0.01" name="h" class="form-control" value="<?php echo e($shipping!=null?$shipping->h:""); ?>">

                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for=""> width <span class="d_class"><?php echo e($shipping!=null?$shipping->shipping->dimensionclass:""); ?></span></label>
                        <input required type="number" step="0.01" name="w" class="form-control" value="<?php echo e($shipping!=null?$shipping->w:""); ?>">

                    </div>
                </div>
            </div>
        </div>
        <div>
            <button class="btn btn-primary">Save Shipping Detail</button>
        </div>


    </form>
</div>
<?php if($shipping!=null): ?>
    <?php
        $shippingprice=$shipping->shippingprice();
    ?>
    <?php if($shippingprice!=null): ?>
        <?php echo $__env->make('admin.product.updateshippingprice',['$shippingprice'=>$shippingprice], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH D:\New folder\ecommerce\resources\views/admin/product/shipping.blade.php ENDPATH**/ ?>