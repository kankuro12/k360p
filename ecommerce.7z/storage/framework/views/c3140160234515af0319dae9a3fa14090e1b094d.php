<div>
    <h4 style="font-weight: 600">Shipping Details</h4>
    <hr>
    <div>
        <?php 
            $option=\App\VendorOptions::where('vendor_id',$vendordetails->id)->first();
            
        ?>
        <?php if($option!=null): ?>

            <div>
                <table  class="table">
                    <tr>
                        <td>
                            <strong>Province</strong>
                        </td>
                        <td>
                            <?php echo e($option->province->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong>District</strong>
                        </td>
                        <td>
                            <?php echo e($option->district->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong>Municipality</strong>
                        </td>
                        <td>
                            <?php echo e($option->Municipality->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong>Shipping Area</strong>
                        </td>
                        <td>
                            <?php echo e($option->shippingarea!=null?$option->shippingarea->name:"--"); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong>Deliver Range</strong>
                        </td>
                        <td>
                            <?php echo e(\App\Setting\VendorOption::deliverrange[$option->deliver_range]); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong>LandMark</strong>
                        </td>
                        <td>
                            <?php echo e($option->landmark); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong>Bulk Buy</strong>
                        </td>
                        <td>
                            <?php echo e($option->bulkbuy==1?"Yes":"No"); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong>Bulk Sell</strong>
                        </td>
                        <td>
                            <?php echo e($option->bulksell==1?"Yes":"No"); ?>

                        </td>
                    </tr>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH D:\New folder\ecommerce\resources\views/admin/vendor/shipping.blade.php ENDPATH**/ ?>