
<?php $__env->startSection('content'); ?>
<?php
    $sel=1;
    if(session('sel')){
        $sel=session('sel');
    }
?>
    <div class="container-fluid">

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <br>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">
                            
                            <strong><a  href="<?php echo e(url('admin/manage-product')); ?>">Products</a> / <?php echo e($productdetail->product_name); ?></strong>
                        </h4>
                        <?php if($productdetail->vendor_id!=0): ?>
                            
                        <p>
                            <?php if($productdetail->isverified==1 ): ?>
                            <span class="label label-success">
                                Verified
                            </span>
                            
                            <span>
                                <a style="color:#F44336; href="<?php echo e(url('admin/product-verify/'.$productdetail->product_id.'/status/0')); ?>">Unverify</a>
                            </span>
                            <?php else: ?>
                            
                            <span class="label label-danger">
                                Not Verified
                            </span>
                            <span>
                                <a href="<?php echo e(url('admin/product-verify/'.$productdetail->product_id.'/status/1')); ?>">Verify</a>
                            </span>
                            <?php endif; ?>
                        </p>
                        <?php endif; ?>
                    </div>
                    <div class="card-content">
                        <div class="row">
                            <div class="col-md-2">
                                <ul class="nav nav-pills nav-pills-icons nav-pills-rose nav-stacked" role="tablist">
                                    <li class="<?php echo e($sel==1?"active":""); ?>">
                                        <a href="#general-info" role="tab" data-toggle="tab" aria-expanded="false">
                                            <i class="material-icons">info</i> General Info
                                        </a>
                                    </li>
                                    <li class="<?php echo e($sel==2?"active":""); ?>">
                                        <a href="#productimages" role="tab" data-toggle="tab" aria-expanded="true">
                                            <i class="material-icons">photo_library</i> Images Gallery
                                        </a>
                                    </li>
                                    <li class="<?php echo e($sel==3?"active":""); ?>">
                                        <a href="#productattribute" role="tab" data-toggle="tab" aria-expanded="true">
                                            <i class="material-icons">notes</i> Stock
                                        </a>
                                    </li>
                                    <li class="<?php echo e($sel==4?"active":""); ?>">
                                        <a href="#productshipping" role="tab" data-toggle="tab" aria-expanded="true">
                                            <i class="material-icons">local_shipping</i> Shipping
                                        </a>
                                    </li>
                                    <li class="<?php echo e($sel==5?"active":""); ?>">
                                        <a href="#extra" role="tab" data-toggle="tab" aria-expanded="true">
                                            <i class="material-icons">bento</i> Extra Details
                                        </a>
                                    </li>
                                    <li class="<?php echo e($sel==6?"active":""); ?>">
                                        <a href="#extracharge" role="tab" data-toggle="tab" aria-expanded="true">
                                            <i class="material-icons">attach_money
                                            </i> Extra Charges
                                        </a>
                                    </li>
                                    <li class="<?php echo e($sel==7?"active":""); ?>">
                                        <a href="#admincharge" role="tab" data-toggle="tab" aria-expanded="true">
                                            <i class="material-icons">attach_money
                                            </i> Admin Charges
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-10">
                                <div class="tab-content">
                                    <div class="tab-pane <?php echo e($sel==1?"active":""); ?>" id="general-info">
                                        <div class="row">
                                        <div class="col-md-6"><h2 style="text-transform: uppercase;"><strong>General Info</strong></h2></div>
                                        <div class="col-md-6"><img class="img img-responsive img-round" style="max-width: 120px;" src="<?php echo e(asset($productdetail->product_images)); ?>" alt=""></div>
                                        </div>
                                        <hr>
                                        <form onsubmit="return false;" class="form-horizontal">
                                        <div class="row">
                                            <label class="col-md-2 label-on-right text-primary">Product Link</label>
                                            <div class="col-md-6">
                                                <div class="form-group label-floating is-empty">
                                                    <label class="control-label"></label>
                                                <input type="text" class="form-control" value="<?php echo e(url('/product/'. $productdetail->product_id)); ?>" id="prodlink">
                                                <span class="material-input"></span></div>
                                            </div>
                                            <div class="col-md-4">
                                                <button onclick="selectLink()" class="btn btn-round btn-primary">Copy</button>
                                            </div>
                                        </div>
                                        </form>
                                        <hr>
                                        <style>
                                            .cc {
                                                border: none;
                                                width: 100%;
                                            }

                                            .cc:focus {
                                                border: black 1px solid;
                                            }

                                        </style>

                                        <form
                                            action="<?php echo e(route('admin.update-product', ['product' => $productdetail->product_id])); ?>"
                                            method="post">
                                            <?php echo csrf_field(); ?>
                                            <p class="prod-desc"><strong>Name: </strong>
                                                <input value="<?php echo e($productdetail->product_name); ?>" type="text" name="product_name" id="P_name" required class="cc">

                                            </p>
                                            <p class="prod-desc"><strong>Stock Type: </strong>
                                                <select name="stocktype" id="stocktype" class="cc">
                                                    <option value="0"
                                                        <?php echo e($productdetail->stocktype == 0 ? 'selected' : ''); ?>>
                                                        Simple</option>
                                                    <option value="1"
                                                        <?php echo e($productdetail->stocktype == 1 ? 'selected' : ''); ?>>
                                                        Variant</option>
                                                </select>

                                            </p>
                                            <p class="prod-desc"><strong>Description: </strong>
                                                <textarea name="product_short_description" id="product_short_description"
                                                    class="cc"><?php echo e($productdetail->product_short_description); ?></textarea>

                                            </p>
                                            <p class="prod-desc"><strong>Category: </strong>
                                                
                                            <select name="category_id" id="category_id" class="cc">
                                                <?php echo $categorydropdown; ?>

                                            </select>
                                            </p>
                                            <p class="prod-desc"><strong>Brand: </strong>
                                                <select name="brand_id" id="brand_id" class="cc">
                                                    <?php echo $branddropdown; ?>

                                                </select>
                                            </p>
                                            
                                            <p class="prod-desc"><strong>Mark Price (Rs) :</strong>
                                                <input required type="number" step="0.01" name="mark_price"
                                                    value="<?php echo e($productdetail->mark_price); ?>" class="cc"
                                                    placeholder="Enter Product Price">


                                            </p>
                                            <p class="prod-desc"><strong>Sale Price (Rs) : </strong>
                                                <input required type="number" step="0.01" name="sell_price"
                                                    value="<?php echo e($productdetail->sell_price); ?>" class="cc"
                                                    placeholder="Enter Product Price">
                                            </p>
                                            <p class="prod-desc"><strong>Tags: </strong>
                                            <div class="cc">
                                                <input value="<?php echo e($productdetail->tags); ?>" name="tags" class="cc" required
                                                    data-role="tagsinput" name="attributeitem" id="attributeitem"
                                                    required />
                                            </div>


                                            </p>
                                            <?php if($productdetail->stocktype == 0): ?>

                                                <p class="prod-desc"><strong>Quantity: </strong>
                                                    <input required type="number" step="0.01" name="quantity"
                                                        value="<?php echo e($productdetail->quantity); ?>" class="cc"
                                                        placeholder="Enter Product Price">


                                                </p>
                                            <?php endif; ?>

                                            <p class="prod-desc"><strong>Featured: </strong>
                                                <input type="checkbox" name="featured" id="featured" <?php echo e($productdetail->featured == 1?"checked":""); ?> value="1">
                                                <?php if($productdetail->featured == 1): ?>
                                                    <span id="featured_text" class="label label-primary">Featured</span>

                                                <?php else: ?>
                                                    <span id="featured_text" class="label label-danger">Not Featured</span>
                                                <?php endif; ?>
                                            </p>
                                            <p>
                                            <div>
                                                <div class="prod-desc">
                                                    <strong>Description</strong>
                                                </div>
                                                <hr>
                                                <div>
                                                    <textarea id="product-desc" class="cc"
                                                        name="product_description" required><?php echo $productdetail->description; ?></textarea>
                                                </div>
                                            </div>
                                            </p>
                                            <p>
                                                <input type="submit" value="Update Product" class="btn btn-primary">
                                            </p>
                                        </form>
                                        
                                    </div>
                                    <div class="tab-pane <?php echo e($sel==2?"active":""); ?>" id="productimages">
                                        <h3>PRODUCT IMAGES</h3>
                                        <hr>
                                        <div class="row">
                                            <?php $__currentLoopData = $productimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productimage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-4 fileinput">
                                                <div style="position: relative;">

                                                    <div class="thumbnail">
                                                        <img src="<?php echo e(asset($productimage->image)); ?>" alt="">
                                                    </div>
                                                    <div style="position: absolute;top:0;right:0;">
                                                        <a href="<?php echo e(url('admin/product-image/del/'.$productimage->product_image_id)); ?>" class="btn btn-danger" >Delete</a>
                                                    </div>
                                                </div>
                                            </div>  
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div>
                                        <form action="<?php echo e(url('admin/product-image/add/'.$productdetail->product_id)); ?>" enctype="multipart/form-data" method="POST">
                                        <?php echo csrf_field(); ?>    
                                            <label for="images">Add Gallery Images (800 x 600)</label>
                                            <div class="row" id="images">
                                                <?php for($i = 0; $i <  env('productimage_count')-count($productimages); $i++): ?>
                                                    <div class="col-md-4 h-100" style="margin-bottom: 5px;min-height:180px;">
                                                        <div style="position: relative">
                                                            <div >
                                                                <input onchange="loadImage(this,<?php echo e($i); ?>)" v="<?php echo e($i); ?>" style="display:none;" name="product_images[]" type="file" id="gal_<?php echo e($i); ?>" accept="image/*"/>
                                                                <img src="<?php echo e(asset('images/backend_images/add_image.png')); ?>" alt="..." id="gal_img_<?php echo e($i); ?>" 
                                                                onclick="document.getElementById('gal_<?php echo e($i); ?>').click();">
                                                            </div>
                                                            <div style="position: absolute;top:0px;right:0px;">
                                                                <span class="btn btn-danger"
                                                                onclick="
                                                                document.getElementById('gal_<?php echo e($i); ?>').value = null;
                                                                document.getElementById('gal_img_<?php echo e($i); ?>').src='<?php echo e(asset('images/backend_images/add_image.png')); ?>';
                                                                "
                                                                >Clear</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endfor; ?>
                                            </div>
                                            <div  style="margin-bottom: 5px;min-height:180px;">
                                                <button class="btn  btn-primary">Save Image</button>
                                            </div>
                                        </form>
                                        </div>
    
                                    </div>
                                    <div class="tab-pane <?php echo e($sel==3?"active":""); ?>" id="productattribute">
                                        <?php if($productdetail->stocktype==1): ?>
                                        <h3>ATTRIBUTES</h3>
                                        <hr>
                                           <?php echo $__env->make('admin.product.VariantStock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php else: ?>
                                        <h3>Stock</h3>
                                        <hr>

                                        <?php echo $__env->make('admin.product.SimpleStock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                       <?php endif; ?>
                                    </div>
                                    <div class="tab-pane <?php echo e($sel==4?"active":""); ?>" id="productshipping" >
                                        <?php echo $__env->make('admin.product.shipping', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    <div class="tab-pane <?php echo e($sel==5?"active":""); ?>" id="extra" >
                                        <?php echo $__env->make('admin.product.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        
                                    </div>
                                    <div class="tab-pane <?php echo e($sel==6?"active":""); ?>" id="extracharge" >
                                        <?php echo $__env->make('admin.product.extracharge', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        
                                    </div>
                                    <div class="tab-pane <?php echo e($sel==7?"active":""); ?>" id="admincharge" >
                                        <?php echo $__env->make('admin.product.admincharges', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/backend-js/ckeditor/ckeditor.js')); ?>"></script>
    <script>
        CKEDITOR.replace('product-desc');
         CKEDITOR.replace('refundablepolicy');
        
        function selectLink(){
            var copylink = document.getElementById("prodlink");
            copylink.select();
            document.execCommand("copy");
            copyLink('top','right');
        }
        function copyLink(from, align) {
        type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: "notifications",
            message: "Link has been <b>Copied</b> to clipboard"

        }, {
            type: type[color],
            delay: 2000,
            timer: 200,
            placement: {
                from: from,
                align: align
            }
        });
    }

    function loadImage(input,i){
            console.log(input,i);
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                
                reader.onload = function(e) {
                $('#gal_img_'+i).attr('src', e.target.result);
                }
                var FileSize = input.files[0].size  / 1024; 
                if(FileSize><?php echo e(env('productimage_size')); ?>){
                    alert('Image Size Cannot Be Greater than 600kb');
                    document.getElementById('gal_img_'+i).src='<?php echo e(asset('images/backend_images/add_image.png')); ?>';
                    input.value=null;
                    console.log(input.files);
                }else{

                    reader.readAsDataURL(input.files[0]); // convert to base64 string
                }
            }
        }

        $("#attribute"). change(function(){
            $('#attributeitem').tagsinput('removeAll');
            var selecteditem = $(this). children("option:selected").data( "id" );
            var items=selecteditem.split(",");
            for (let index = 0; index < items.length; index++) {
                const item = items[index];
                $('#attributeitem').tagsinput('add', item);
                console.log(item);
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayouts.admin-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/admin/viewproduct.blade.php ENDPATH**/ ?>