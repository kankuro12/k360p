
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
        <div class="col-md-12">
            <?php if(Session::has('msg')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('msg')); ?></div>
            <?php endif; ?>
            <a href="<?php echo e(url('admin/add-product')); ?>" class="create_modal btn btn-fill btn-primary" >Add Product</a>
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="purple">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">Products</h4>
                    <div class="content-view">
                    <div class="material-datatables">
                        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                            <div class="row">
                                <div class="col-md-3">
                                    <select class="selectpicker" data-live-search="true" id="brand-search" name="brandsearch" data-style="btn btn-rose" title="Search By Brand" data-size="3">
                                        <?php echo $branddropdown; ?>

                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <select class="selectpicker" data-live-search="true" id="category-search" name="categorysearch" data-style="btn btn-rose" title="Search By Category" data-size="3">
                                        <?php echo $categorydropdown; ?>

                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <select class="selectpicker" data-live-search="true" id="rate-search" name="ratesearch" data-style="btn btn-rose" title="Search By Rating" data-size="3">
                                        <option disabled selected>Search by Ratings</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <select class="selectpicker" data-live-search="true" id="stock-status-search" name="stocksearch" data-style="btn btn-rose" title="Single Select" data-size="3">
                                        <?php echo $statusdropdown; ?>

                                    </select>
                                </div>
                            </div>
                            <thead>
                                <tr>
                                    <th class="text-center">Product Code</th>
                                    <th class="text-center">Name</th>
                                    <th class="text-center">image</th>
                                    <th class="text-center">Brand</th>
                                    <th class="text-center">Quantity</th>
                                    <th class="text-center">Featured</th>
                                    <th class="disabled-sorting text-center">Actions</th>
                                </tr>
                            </thead>
                            
                            <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($product->product_code); ?></td>
                                    <td class="text-center"><?php echo e($product->product_name); ?></td>
                                    <td class="text-center"><img style="max-width: 120px;" src="<?php echo e(asset('images/backend_images/products/main_image/'.$product->product_images)); ?>" alt=""></td>
                                    <td class="text-center"><?php echo e($product->brand_name); ?></td>
                                    
                                    <td class="text-center"><?php echo e($product->quantity); ?></td>
                                    <td class="text-center"><input type="checkbox" name="featured" value='<?php echo e($product->featured); ?>' onchange="setfet(this)" data-id ="<?php echo e($product->product_id); ?>" <?php if($product->featured == 1): ?> checked  <?php endif; ?> >
                                        <span class="label label-primary <?php if($product->featured == 0): ?>hidden <?php endif; ?>">Featured</span> 
                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(url('/admin/view-product/'. $product->product_id)); ?>" data-toggle="tooltip" data-placement="top" title="View" class="btn  btn-just-icon btn-round btn-rose"><i class="material-icons">view_list</i></a>
                                        <a href="<?php echo e(url('/admin/edit-product/'.$product->product_id)); ?>" data-toggle="tooltip" data-placement="left" title="Edit" class="btn btn-just-icon  btn-round btn-primary"><i class="material-icons">border_color</i></a>
                                        <a href="#" data-toggle="tooltip" data-placement="left" title="Delete" class="btn btn-just-icon  btn-round btn-danger"><i class="material-icons">delete_forever</i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    </div>
                </div>
                <!-- end content-->
            </div>
            <!--  end card  -->
        </div>
        <!-- end col-md-12 -->
    </div>
    <!-- end row -->
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    
    function setfet(p){
        //console.log(p.value);
       
        //console.log(p.dataset.id);
        if(p.value == 1){
            //console.log('featured');
            
            p.value = 0;
        }else if(p.value == 0){
            //console.log('unfeatured');
            p.value = 1;
        }

        $.ajax({
            type: 'post',
            url: '/admin/setfeatured',
            data: { 'feature': p.value, 'product_id': p.dataset.id },
            success: function(data){
                if(p.value==1){
                    $(p).siblings("span").removeClass("hidden");
                }else{
                    $(p).siblings("span").addClass("hidden");
                }
            },

        });
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayouts.admin-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/admin/manageproducts.blade.php ENDPATH**/ ?>