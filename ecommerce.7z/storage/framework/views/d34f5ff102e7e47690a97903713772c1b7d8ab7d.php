<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-block">
	<button type="button" class="close" data-dismiss="alert" style="margin-top: 10px;">×</button>
        <strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>

<?php if($message = Session::get('warning')): ?>
<div class="alert alert-warning alert-block">
	<button type="button" class="close" data-dismiss="alert" style="margin-top: 10px;">×</button>
        <strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?><?php /**PATH D:\New folder\ecommerce\resources\views/themes/molla/layouts/message.blade.php ENDPATH**/ ?>