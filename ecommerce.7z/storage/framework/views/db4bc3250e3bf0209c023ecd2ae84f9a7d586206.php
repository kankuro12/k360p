<div>
    <h4 style="font-weight: 600">Verification Details</h4>
    <hr>
    <div>
        <?php $verification = \App\VendorVerification::where('vendor_id', $vendordetails->id)->first();
        ?>
        <?php if($verification != null): ?>

            <table class="table">
                <tr>
                    <td> <strong>Bank</strong> </td>
                    <td><?php echo e($verification->bankname); ?></td>
                </tr>
                <tr>
                    <td> <strong>Bank</strong> </td>
                    <td><?php echo e($verification->bankaccount); ?></td>
                </tr>
            </table>
            <hr>
            <div class="row">
                <div class="col-md-6">
                    <div><strong>Registration Document</strong> </div>
                    <img src="<?php echo e(url($verification->registration)); ?>" style="width: 100%;">
                </div>
                <div class="col-md-6">
                    <div><strong>Citizenship</strong> </div>
                    <img src="<?php echo e(url($verification->citizenship)); ?>" style="width: 100%;">
                </div>
            </div>

        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\New folder\ecommerce\resources\views/admin/vendor/verification.blade.php ENDPATH**/ ?>