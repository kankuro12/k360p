<?php
$group=$data->getElement();
?>

<div class="intro-slider-container slider-container-ratio mb-2 ">
    <div class="intro-slider owl-carousel owl-simple owl-nav-inside" data-toggle="owl" data-owl-options='{
            "nav": true, 
            "dots": true,
            "autoHeight":true
        }'>
        <?php $__currentLoopData = $group->sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="intro-slide">
                <img src="<?php echo e(asset($slider->slider_image)); ?>" alt="Image Desc" style="width:100%;">
                

                <div class="intro-content">
                    <h3 class="intro-subtitle"><?php echo $slider->secondary_text; ?></h3><!-- End .h3 intro-subtitle -->
                    <h1 class="intro-title text-white">
                        <?php echo $slider->primary_text; ?>

                    </h1><!-- End .intro-title -->

                    <div class="intro-text text-white">
                        <?php echo $slider->secondary_text; ?>

                    </div><!-- End .intro-text -->

                    <a href="<?php echo e($slider->link_text); ?>" class="btn btn-primary">
                        <span><?php echo $slider->button_text; ?></span>
                        <i class="icon-long-arrow-right"></i>
                    </a>
                </div><!-- End .intro-content -->
            </div><!-- End .intro-slide -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div><!-- End .intro-slider owl-carousel owl-simple -->

    <span class="slider-loader"></span><!-- End .slider-loader -->
</div><!-- End .intro-slider-container -->
<?php /**PATH D:\New folder\ecommerce\resources\views/themes/molla/elements/slider.blade.php ENDPATH**/ ?>