<div>
    <hr>
    <h4>
        <strong>Shipping Price</strong>
    </h4>
    <?php
        $arr=$shippingprice->toArray();
    ?>
    <form action="<?php echo e(route('admin.product-shipping-price')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="product_id" value="<?php echo e($shippingprice->product_id); ?>">
    <input type="hidden" name="shipping_class_id" value="<?php echo e($shippingprice->shipping_class_id); ?>">
    <?php $i=0;?>
    <?php $__currentLoopData = \App\Setting\VendorOption::deliverrange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label ><?php echo e($item); ?></label>
                <input class="form-control"  type="number" name="amount_<?php echo e($i); ?>" id="amount_<?php echo e($i); ?>" value="<?php echo e($arr['amount_'.$i]); ?>">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <select class="selectpicker" data-live-search="true" id="type_<?php echo e($i); ?>" name="type_<?php echo e($i); ?>"
                    data-style="btn btn-primary " title="Select A Price Method" data-size="6" required >
                    <?php $__currentLoopData = \App\Setting\VendorOption::shippingoption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e($arr['type_'.$i]==$key?"selected":""); ?>>
                            <?php echo e($option); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        
    </div>
    <?php $i+=1; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div >
            <div class="form-group">
                <input type="submit" value="Update" class="btn btn-primary">
            </div>
        </div>
    </form>
</div><?php /**PATH D:\New folder\ecommerce\resources\views/admin/product/updateshippingprice.blade.php ENDPATH**/ ?>