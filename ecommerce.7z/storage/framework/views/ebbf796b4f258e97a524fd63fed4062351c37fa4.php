<div>
    <form action="<?php echo e(url('admin/product-attribute/add/' . $productdetail->product_id)); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col-md-4">
                <select class="selectpicker" data-live-search="true" id="attribute" name="attribute"
                    data-style="btn btn-primary " title="Select Attribute" data-size="3" required>
                    <?php $__currentLoopData = App\model\admin\Attribute_group::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option data-id="<?php echo e($item->str_attributes()); ?>" value="<?php echo e($item->attribute_group_name); ?>">
                            <?php echo e($item->attribute_group_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-8 p-2">
                <label for="attributeitem">write attribute and press enter</label>
                <div style="border : red 1px solid;">
                    <input required data-role="tagsinput" name="attributeitem" id="attributeitem" required />
                </div>

            </div>

        </div>
        <div>
            <button class="btn btn-primary">Add Attribute</button>
        </div>
    </form>
</div>
<hr>
<div>
    <div class="row">
        <?php $__currentLoopData = App\model\admin\Product_attribute::where('product_id', $productdetail->product_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <ul class="list-group">
                    <li class="list-group-item active">
                        <a href="<?php echo e(url('/admin/product-attribute/del/' . $attribute->id)); ?>" class="badge">del</a>
                        <?php echo e($attribute->name); ?>

                    </li>
                    <?php $__currentLoopData = $attribute->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <a href="<?php echo e(url('/admin/product-attribute-item/del/' . $item->id)); ?>" class="badge">del</a>
                            <?php echo e($item->name); ?>

                        </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <form action="<?php echo e(url('admin/product-attribute-item/add/' . $attribute->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <label for="attributeitem">Write attributes and press enter</label>
                            <div style="border : red 1px solid;">
                                <input required data-role="tagsinput" name="attributeitem"
                                    id="attributeitem_<?php echo e($attribute->id); ?>" required />
                            </div>
                            <button class="btn btn-primary">Add attributes</button>
                        </form>
                    </li>
                </ul>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<hr>
<?php
    $attributes=App\model\admin\Product_attribute::where('product_id', $productdetail->product_id)->get();

?>
<?php if($attributes->count()>0): ?> 
<div id="placement">
    <h2 style="font-weight: 800">Add Stock</h2>
    <hr>
    <form action="<?php echo e(url('admin/product-stock/add/' . $productdetail->product_id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">

            <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <input type="hidden" name="attributes[]" value="<?php echo e($attribute->id); ?>" />
                    <select class="selectpicker" data-live-search="true" id="attribute_<?php echo e($attribute->id); ?>"
                        name="attribute_<?php echo e($attribute->id); ?>" data-style="btn btn-primary "
                        title="Select A <?php echo e($attribute->name); ?>" data-size="3" required>
                        <?php $__currentLoopData = $attribute->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>">
                                <?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label >Price</label>
                    <input required type="number" value="<?php echo e($productdetail->mark_price); ?>" min="0" class="form-control"
                        id="price" placeholder="Price" name="price">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="">Sale Price</label>
                    <input required type="number" value="<?php echo e($productdetail->mark_price); ?>" min="0" class="form-control"
                        id="saleprice" name="saleprice" placeholder="Sale Price">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="">Quantity</label>
                    <input required type="number" value="0" min="0" class="form-control" id="qty" name="qty"
                        placeholder="Quantity">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <button class="btn btn-primary">Add Stock</button>
                </div>
            </div>
        </div>
    </form>
    <hr>
    <div>
        <table class="table">
            <thead>
                <tr>
                    <th>
                        Variant
                    </th>
                    <th>
                        Price
                    </th>
                    <th>
                        SalePrice
                    </th>
                    <th>
                        Quantity
                    </th>
                    <th>
                        Action
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = App\model\ProductStock::where('product_id',$productdetail->product_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <form action="<?php echo e(url('admin/product-stock/update/'.$stock->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                        <td>
                            <?php $__currentLoopData = App\Setting\VariantManager::codeToString($stock->code); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p>
                                    <?php echo e($item['attribute']['name']); ?>: <?php echo e($item['item']['name']); ?>

                                </p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </td>
                        <td>
                            <input type="number" name="price" id="stoc_price" value="<?php echo e($stock->price); ?>" />
                        </td>
                        <td>
                            <input type="number" name="saleprice" id="stoc_saleprice" value="<?php echo e($stock->saleprice); ?>" />
                        </td>
                        <td>
                            <input type="number" name="qty" id="stoc_qty" value="<?php echo e($stock->qty); ?>" />
                        </td>
                        <td>
                            <button class="btn btn-primary">update</button>
                        </td>
                        </form>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
<?php /**PATH D:\New folder\ecommerce\resources\views/admin/product/VariantStock.blade.php ENDPATH**/ ?>