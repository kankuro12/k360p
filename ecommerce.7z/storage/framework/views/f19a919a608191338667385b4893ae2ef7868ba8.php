

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <?php if(Session::has('msg')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('msg')); ?></div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="purple">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">Products</h4>
                    <div class="content-view">
                    <div class="material-datatables">
                        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                            <thead>
                                <tr>
                                   
                                    <th>Name</th>
                                
                                    <th>Brand</th>
                                    <th>Stock Status</th>
                                    <th>Quantity</th>
                                    <th class="disabled-sorting text-right">Actions</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                  
                                    <th>Name</th>
                                   
                                  
                                    <th>Brand</th>
                                    <th>Stock Status</th>
                                    <th>Quantity</th>
                                    <th class="text-right">Actions</th>
                                </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                
                                    <td><?php echo e($product->product_name); ?></td>
                                    <td><?php echo e($product->brand_name); ?></td>
                                    <td><?php echo e($product->stock_status_name); ?></td>
                                    <td><?php echo e($product->quantity); ?></td>
                                    <td class="text-right">
                                        <a href="#" class="btn  btn-simple btn-info btn-icon  like"><i class="material-icons">favorite</i></a>
                                        <a href="<?php echo e(route('vendor.view-product',['id'=>$product->product_id])); ?>" class="btn btn-simple  btn-warning btn-icon  edit"><i class="material-icons">dvr</i></a>
                                        <a href="#" class="btn btn-simple  btn-danger btn-icon  remove"><i class="material-icons">close</i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    </div>
                </div>
                <!-- end content-->
            </div>
            <!--  end card  -->
        </div>
            <!-- end col-md-12 -->
    </div>
        <!-- end row -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sellerlayouts.seller-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/vendor/manageproduct.blade.php ENDPATH**/ ?>