<form action="<?php echo e(route('elements.update-boxed',['item'=>$item->id])); ?>" method="post">
    <?php echo csrf_field(); ?>

    <div class="row">
        
        <div class="col-md-12">
            <div class="form-group">
                <label >
                    <input type="checkbox" name="hascategory" id="hascategory" value="1" <?php echo e($item->hascategory==1?"checked":""); ?>> Has Category
                </label>
                <select name="category_id" id="category_id"  required style="width: 100%">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->cat_id); ?>" <?php echo e($item->category_id==$cat->cat_id?"selected":""); ?>><?php echo e($cat->cat_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>   
        <div class="col-md-12">
            <div class="form-group">
                <label >
                    Title
                </label>
               <input type="text" name="title" id="title" style="width: 100%" value="<?php echo e($item->title); ?>" placeholder="Enter Title">
            </div>
        </div>   
        <div class="col-md-4">
            <label >Order By</label>
            <select name="orderby" id="orderby" style="width: 100%" required>
                <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($col); ?>" <?php echo e($item->orderby==$col?"selected":""); ?>><?php echo e($col); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-4">
            <label >Order </label>
            <select name="order" id="order" style="width: 100%" required>
                <option value="0" <?php echo e($item->order==0?"selected":""); ?>>Asc</option>
                <option value="1" <?php echo e($item->order==1?"selected":""); ?>>Desc</option>
            </select>
        </div>
        <div class="col-md-4">
            <label >No of Displayed Product</label>
            <input value="<?php echo e($item->count); ?>" min="1" type="number" name="count" id="count"style="width: 100%" required>
        </div>

        <div class="col-md-12">
            <label ><input type="checkbox" name="hasquery" id="hasquery" value="1" <?php echo e($item->hasquery==1?"checked":""); ?>> Custom Query</label>
            <textarea name="mquery"  id="query" cols="30" rows="10" style="width:100%;"><?php echo e($item->query); ?></textarea>
        </div>

        <div class="col-md-4">
            <input type="submit" value="update" class="btn btn-primary">
         
            <a href="<?php echo e(route('elements.del-boxed',['item'=>$item->id])); ?>" class="btn btn-danger">Delete</a>
        </div>
    </div>
</form><?php /**PATH D:\New folder\ecommerce\resources\views/admin/elements/boxeddisplayitem.blade.php ENDPATH**/ ?>