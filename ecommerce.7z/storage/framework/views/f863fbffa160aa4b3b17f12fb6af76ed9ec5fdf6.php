<?php
$boxed=$data->getElement();
$items=$boxed->items;
?>
<div class="bg-lighter trending-products">
    <div class="heading heading-flex mb-3">
        <div class="heading-left">
            <h2 class="title"><?php echo e($boxed->title); ?></h2><!-- End .title -->
        </div><!-- End .heading-left -->

        <div class="heading-right">
            <ul class="nav nav-pills justify-content-center" role="tablist">
                <?php $i=0;?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <li class="nav-item">
                    <a class="nav-link <?php echo e($i==0?"active":""); ?>" id="trending-all-link" data-toggle="tab" href="#boxeditems_<?php echo e($item->id); ?>" role="tab" aria-controls="trending-all-tab" aria-selected="true"><?php echo e($item->title); ?></a>
                </li>
                <?php $i+=1;?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </ul>
        </div><!-- End .heading-right -->
    </div><!-- End .heading -->

    <div class="tab-content tab-content-carousel">
        <?php $i=0;?>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php echo $__env->make(\App\Setting\HomePage::theme('elements.boxeditem'),['item'=>$item,'i'=>$i], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php $i+=1;?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </div><!-- End .tab-content -->
</div><!-- End .bg-lighter --><?php /**PATH D:\New folder\ecommerce\resources\views/themes/molla/elements/boxed.blade.php ENDPATH**/ ?>