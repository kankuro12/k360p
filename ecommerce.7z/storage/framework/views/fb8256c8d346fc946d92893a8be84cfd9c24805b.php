
<?php $__env->startSection('content'); ?>
    <div style="padding:50px;">
        <div class="card">
            <div class="card-header card-header-icon" data-background-color="purple">
                <i class="material-icons">map</i>
            </div>
            <div class="card-content">
                <h3 class="card-title">Shipping Zones</h3>
                <div class="toolbar">
                    <!--        Here you can write extra buttons/actions for the toolbar              -->
                </div>
                <div class="content-view">
                    <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button class="btn  text-left" type="button" data-toggle="collapse"
                            data-target="#province_<?php echo e($province->id); ?>" aria-expanded="false"
                            aria-controls="collapseExample" style="width:100%;text-align:left;margin:5px 0 0 0 ;">
                            <?php echo e($province->name); ?>

                        </button>
                        <div class="collapse" style="padding-left:40px;" id="province_<?php echo e($province->id); ?>">
                            <?php $__currentLoopData = $province->districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button class="btn  text-left" type="button" data-toggle="collapse"
                                    data-target="#district_<?php echo e($district->id); ?>" aria-expanded="false"
                                    aria-controls="collapseExample" style="width:100%;text-align:left;margin:5px 0 0 0 ;">
                                    <?php echo e($district->name); ?>

                                </button>
                                <div class="collapse" style="padding-left:40px;" id="district_<?php echo e($district->id); ?>">
                                    <?php $__currentLoopData = $district->municipalities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <button class="btn text-left" type="button" data-toggle="collapse"
                                            data-target="#municipality_<?php echo e($municipality->id); ?>" aria-expanded="false"
                                            aria-controls="collapseExample"
                                            style="width:100%;text-align:left;margin:5px 0 0 0 ;">
                                            <?php echo e($municipality->name); ?>

                                        </button>
                                        <div class="collapse" style="padding-left:40px;"
                                            id="municipality_<?php echo e($municipality->id); ?>">
                                            <div>
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <input class="form-control"
                                                            placeholder="Enter New Shipping Zone Name"
                                                            id="mun_<?php echo e($municipality->id); ?>_input">
                                                    </div>
                                                    <div class="col-md-4">
                                                        <button onclick="addarea(<?php echo e($municipality->id); ?>)"
                                                            class="btn btn-primary">Add
                                                            New Zone</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <ul id="mun_<?php echo e($municipality->id); ?>_items">
                                                    <?php $__currentLoopData = $municipality->areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li id="mun_item_<?php echo e($area->id); ?>">
                                                            <div class="row">
                                                                <div class="col-md-7">

                                                                    <input class="form-control" type="text"
                                                                        value="<?php echo e($area->name); ?>"
                                                                        id="mun_item_<?php echo e($area->id); ?>_input">
                                                                </div>
                                                                <div class="col-md-5">
                                                                    <br>
                                                                    <span>
                                                                        <span class=" btn-link"
                                                                            onclick="updatearea(<?php echo e($area->id); ?>)"
                                                                            style="color:red;">Update
                                                                        </span>
                                                                    </span>
                                                                    <span>
                                                                        <span class=" btn-link"
                                                                            onclick="delarea(<?php echo e($area->id); ?>)"
                                                                            style="color:red;">Delete
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function addarea(mun_id) {
            name = $('#mun_' + mun_id + '_input').val();
            if (name == "") {
                alert('Enter Shipping area Name');
            }
            data = {
                'mun_id': mun_id,
                'name': name
            };
            $.ajax({
                type: 'POST',
                url: '/admin/shipping-zones-add',
                data: data,
                success: function(data) {
                    if (data.success) {
                        $('#mun_' + mun_id + '_items').append('<li id="mun_item_' + data.area.id +
                            '"> <div class="row"> <div class="col-md-7"><input class="form-control" type="text" value="' +
                            data.area.name + '" id="mun_item_' + data.area.id +
                            '_input"></div><div class="col-md-5"><br> <span><span class=" btn-link" onclick="updatearea(' +
                            data.area.id +
                            ')" style="color:red;">Update </span> </span> <span> <span class=" btn-link" onclick="delarea(' +
                            data.area.id + ')" style="color:red;">Delete</span> </span></div></div> </li>');
                        $('#mun_' + mun_id + '_input').val('');
                    }
                },
            });
        }

        function delarea(id) {
            data = {
                'id': id
            };
            $.ajax({
                type: 'POST',
                url: '/admin/shipping-zones-del',
                data: data,
                success: function(data) {
                    if (data.success) {
                        $('#mun_item_' + id).remove();
                    }
                },
            });
        }

        function updatearea(id) {
            name = $('#mun_item_' + id + '_input').val();
            if (name == "") {
                alert('Enter Shipping area Name');
            }
            data = {
                'id': id,
                'name': name
            };
            $.ajax({
                type: 'POST',
                url: '/admin/shipping-zones-update',
                data: data,
                success: function(data) {
                    if (data.success) {

                    }
                },
            });
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayouts.admin-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\ecommerce\resources\views/admin/shipping/zones.blade.php ENDPATH**/ ?>